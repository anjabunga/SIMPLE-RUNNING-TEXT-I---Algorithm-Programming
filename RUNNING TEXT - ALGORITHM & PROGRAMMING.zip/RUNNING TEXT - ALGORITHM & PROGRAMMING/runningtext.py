from tkinter import *

root=Tk()
root.title('UAS PRAKTIKUM ALGOPRO')
canvas=Canvas(root,bg='blue')
canvas.pack(fill=BOTH, expand=TRUE)
isi="Bismillah Nilai A aamiin"
text=canvas.create_text(0,-2000, text=isi, font=('Times New Roman',30,'bold'), fill='white')
x1,y1,x2,y2 = canvas.bbox(text)
width = x2-x1
height = y2-y1
canvas['width']= width
canvas['height']=height
fps=20

def shift():
    x1,y1,x2,y2 = canvas.bbox(text)
    if(x2<0 or y1<0): 
        x1 = canvas.winfo_width()
        y1 = canvas.winfo_height()//2
        canvas.coords(text,x1,y1)
    else:
        canvas.move(text, -4, 0)
    canvas.after(100//fps, shift) 
    
shift()
root.mainloop()